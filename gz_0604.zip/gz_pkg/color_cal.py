#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
import cv2
import numpy as np


class ImageDisplayNode(Node):
    def __init__(self):
        super().__init__('image_display_node')

        # ROS 이미지를 OpenCV 이미지로 변환하기 위한 CvBridge 초기화
        self.bridge = CvBridge()

        # 압축 이미지 토픽 구독 (qos_profile_sensor_data 사용)
        self.image_sub = self.create_subscription(
            CompressedImage, 
            'image_raw/compressed', 
            self.image_callback, 
            qos_profile_sensor_data
        )

        self.window_name = "HSV Tuning (with CLAHE)"
        cv2.namedWindow(self.window_name)

        cv2.createTrackbar("H_LOW_color_start", self.window_name, 20, 180, lambda x: None)
        cv2.createTrackbar("H_HIGH_color_end", self.window_name, 40, 180, lambda x: None)

        cv2.createTrackbar("S_LOW_vivid_min", self.window_name, 100, 255, lambda x: None)
        cv2.createTrackbar("S_HIGH_vivid_max", self.window_name, 255, 255, lambda x: None)

        cv2.createTrackbar("V_LOW_bright_min", self.window_name, 100, 255, lambda x: None)
        cv2.createTrackbar("V_HIGH_bright_max", self.window_name, 255, 255, lambda x: None)
        
        self.get_logger().info("HSV Tuning Started. Press 's' to save values, 'q' to quit.")

    def image_callback(self, msg):
        try:
            # CompressedImage 메시지를 OpenCV BGR 이미지로 변환
            frame = self.bridge.compressed_imgmsg_to_cv2(msg, "bgr8")
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")
            return

        # 1. 해상도 리사이즈
        frame = cv2.resize(frame, (320, 240))
        height, width = frame.shape[:2]

        # 2. 사다리꼴 관심영역(ROI) 지정
        roi_vertices = np.array([[
            (0, 180),                       # 좌측 하단
            (int(110), int(80)),  # 좌측 상단 
            (int(200), int(80)),  # 우측 상단 
            (width, 180)                    # 우측 하단 
        ]], dtype=np.int32)

        # 빈 화면(검은색)에 사다리꼴 모양만 하얗게 칠한 마스크 생성
        roi_mask = np.zeros_like(frame)
        cv2.fillPoly(roi_mask, roi_vertices, (255, 255, 255))
        
        # 원본 이미지와 ROI 마스크를 합쳐서 관심 영역만 남기기 (나머지는 검은색 처리)
        frame = cv2.bitwise_and(frame, roi_mask)

        # 3. 영상 처리 및 HSV 마스킹
        blurred = cv2.GaussianBlur(frame, (5, 5), 0)
        hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

        # ─── [핵심 추가] 적응형 히스토그램 평활화 (CLAHE) 적용 ───
        h, s, v = cv2.split(hsv)  # HSV 채널 분리
        
        # 그림자 제거용 CLAHE 객체 생성
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        v_clahe = clahe.apply(v)  # 밝기(V) 채널에만 적용
        
        # 다시 HSV로 병합
        hsv_clahe = cv2.merge([h, s, v_clahe])
        
        # 시각화를 위해 평활화된 이미지를 BGR로 되돌림 (결과 확인용)
        clahe_bgr = cv2.cvtColor(hsv_clahe, cv2.COLOR_HSV2BGR)
        # ─────────────────────────────────────────────────────────

        h_min = cv2.getTrackbarPos("H_LOW_color_start", self.window_name)
        h_max = cv2.getTrackbarPos("H_HIGH_color_end", self.window_name)

        s_min = cv2.getTrackbarPos("S_LOW_vivid_min", self.window_name)
        s_max = cv2.getTrackbarPos("S_HIGH_vivid_max", self.window_name)

        v_min = cv2.getTrackbarPos("V_LOW_bright_min", self.window_name)
        v_max = cv2.getTrackbarPos("V_HIGH_bright_max", self.window_name)

        lower = np.array([h_min, s_min, v_min])
        upper = np.array([h_max, s_max, v_max])

        # 기존 hsv 대신 "평활화가 적용된 hsv_clahe"를 사용하여 마스크 생성
        mask = cv2.inRange(hsv_clahe, lower, upper)
        
        # 결과 화면에도 평활화되어 밝아진 이미지를 띄워줌
        result = cv2.bitwise_and(clahe_bgr, clahe_bgr, mask=mask)

        # mask는 흑백이라 BGR로 변환해야 원본/결과와 붙일 수 있음
        mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)

        # [원본] | [마스크] | [CLAHE 적용 후 결과] 형태로 나란히 출력
        combined = np.hstack((frame, mask_bgr, result))

        cv2.imshow(self.window_name, combined)

        key = cv2.waitKey(1) & 0xFF

        if key == ord('s'):
            print()
            print("========== [현재 HSV 범위] ==========")
            print(f"lower = np.array([{h_min}, {s_min}, {v_min}])")
            print(f"upper = np.array([{h_max}, {s_max}, {v_max}])")
            print("=====================================")
            print()

        elif key == ord('q'):
            cv2.destroyAllWindows()
            rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    node = ImageDisplayNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()


if __name__ == '__main__':
    main()