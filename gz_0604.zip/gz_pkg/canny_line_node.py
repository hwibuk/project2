#!/usr/bin/env python3
import os
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data, QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import numpy as np

# ==============================================================================
os.environ['ROS_DOMAIN_ID'] = '30'

TARGET_IP_1 = "192.168.0.125"
TARGET_IP_2 = "192.168.0.110"
TARGET_IP_3 = "192.168.0.155"

os.environ['CYCLONEDDS_URI'] = f"""
<CycloneDDS>
    <Domain>
        <General>
            <AllowMulticast>false</AllowMulticast>
        </General>
        <Discovery>
            <Peers>
                <Peer Address="{TARGET_IP_1}"/>
                <Peer Address="{TARGET_IP_2}"/>
                <Peer Address="{TARGET_IP_3}"/>
            </Peers>
            <ParticipantIndex>auto</ParticipantIndex>
        </Discovery>
    </Domain>
</CycloneDDS>
"""
# ==============================================================================


def region_of_interest(img, vertices):
    mask = np.zeros_like(img)
    cv2.fillPoly(mask, vertices, 255)
    return cv2.bitwise_and(img, mask)


def draw_lane_lines(img, left_line, right_line, color=(0, 255, 0), thickness=6):
    line_img = np.zeros_like(img)
    if left_line is not None:
        cv2.line(line_img,
                 (left_line[0], left_line[1]),
                 (left_line[2], left_line[3]),
                 color, thickness)
    if right_line is not None:
        cv2.line(line_img,
                 (right_line[0], right_line[1]),
                 (right_line[2], right_line[3]),
                 color, thickness)
    return cv2.addWeighted(img, 1.0, line_img, 0.9, 0.0)


class VisionNode(Node):
    def __init__(self):
        super().__init__('vision_node')

        self.image_sub = self.create_subscription(
            CompressedImage, '/image_raw/compressed', self.image_callback, qos_profile_sensor_data)

        self.vision_pub = self.create_publisher(String, '/vision_status', 10)
        self.state_sub = self.create_subscription(String, '/control_state', self.state_callback, 10)

        best_effort_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.image_pub = self.create_publisher(CompressedImage, '/image_line/compressed', best_effort_qos)

        self.bridge = CvBridge()

        self.lane_width = 450
        self.last_valid_target_x = None
        self.crosswalk_detected = False
        self.current_control_state = "CRUISE"
        self.last_sent_cmd = ""

        # 이력 버퍼 (시간적 스무딩)
        self.target_x_history   = []
        self.left_line_history  = []
        self.right_line_history = []

    def state_callback(self, msg):
        parts = msg.data.split('|', 1)
        if len(parts) == 2:
            self.current_control_state, self.last_sent_cmd = parts

    # ── CLAHE 전처리: 조명 불균일 보정 ──────────────────────────────────────
    def preprocess(self, bgr_img):
        lab = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        lab = cv2.merge([l, a, b])
        return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    # ── 횡단보도 제거 (numpy 벡터화) ────────────────────────────────────────
    def remove_crosswalk(self, mask_black):
        diff = np.diff(mask_black.astype(np.int16), axis=1)
        runs_per_row = np.sum(diff > 0, axis=1)
        crosswalk_rows = runs_per_row >= 3
        result = mask_black.copy()
        result[crosswalk_rows] = 0
        return result, int(np.sum(crosswalk_rows))

    # ── 시간적 스무딩 ────────────────────────────────────────────────────────
    def smooth_value(self, history, new_val, maxlen=5):
        history.append(new_val)
        if len(history) > maxlen:
            history.pop(0)
        return int(np.mean(history))

    def smooth_line(self, history, new_line, maxlen=5):
        if new_line is not None:
            history.append(new_line)
            if len(history) > maxlen:
                history.pop(0)
        if len(history) == 0:
            return None
        return tuple(int(np.mean([h[i] for h in history])) for i in range(4))

    # ── Hough 기반 차선 검출 ─────────────────────────────────────────────────
    def detect_lane_hough(self, bgr_roi):
        height, width = bgr_roi.shape[:2]

        # HLS 마스킹 (흰색 + 노란색)
        rgb = cv2.cvtColor(bgr_roi, cv2.COLOR_BGR2RGB)
        hls = cv2.cvtColor(rgb, cv2.COLOR_RGB2HLS)
        white_mask  = cv2.inRange(hls, np.array([0,  200,   0]), np.array([180, 255, 255]))
        yellow_mask = cv2.inRange(hls, np.array([15,  30, 115]), np.array([35,  204, 255]))
        mask = cv2.bitwise_or(white_mask, yellow_mask)

        blur  = cv2.GaussianBlur(mask, (5, 5), 0)
        edges = cv2.Canny(blur, 50, 150)

        # 사다리꼴 ROI (원본과 동일)
        roi_vertices = np.array([[
            (0,     400),   # 좌하
            (240,   200),   # 좌상
            (400,   200),   # 우상
            (640,   400)    # 우하
        ]], dtype=np.int32)
        cropped_edges = region_of_interest(edges, roi_vertices)

        # Hough 변환
        lines = cv2.HoughLinesP(
            cropped_edges,
            rho=1,
            theta=np.pi / 180,
            threshold=30,
            minLineLength=20,
            maxLineGap=100
        )

        left_x, left_y   = [], []
        right_x, right_y = [], []

        if lines is not None:
            for line in lines:
                for x1, y1, x2, y2 in line:
                    if x2 == x1:
                        continue
                    slope = (y2 - y1) / (x2 - x1)
                    if abs(slope) < 0.5:
                        continue
                    if slope < 0:
                        left_x.extend([x1, x2])
                        left_y.extend([y1, y2])
                    else:
                        right_x.extend([x1, x2])
                        right_y.extend([y1, y2])

        min_y = 200   # ROI 상단 y (원본과 동일)
        max_y = 400   # ROI 하단 y (원본과 동일)
        raw_left  = None
        raw_right = None

        if len(left_x) > 0:
            left_fit = np.polyfit(left_y, left_x, 1)
            raw_left = (
                int(np.polyval(left_fit, max_y)), max_y,
                int(np.polyval(left_fit, min_y)), min_y
            )

        if len(right_x) > 0:
            right_fit = np.polyfit(right_y, right_x, 1)
            raw_right = (
                int(np.polyval(right_fit, max_y)), max_y,
                int(np.polyval(right_fit, min_y)), min_y
            )

        left_line  = self.smooth_line(self.left_line_history,  raw_left)
        right_line = self.smooth_line(self.right_line_history, raw_right)

        return left_line, right_line, cropped_edges, roi_vertices

    # ── 메인 콜백 ────────────────────────────────────────────────────────────
    def image_callback(self, msg):
        cv_image = self.bridge.compressed_imgmsg_to_cv2(msg, "bgr8")
        cv_image = self.preprocess(cv_image)  # CLAHE 조명 보정

        roi   = cv_image.copy()
        roi_h, roi_w = roi.shape[:2]

        if self.last_valid_target_x is None:
            self.last_valid_target_x = roi_w // 2

        # ── Hough 차선 검출 ──
        left_line, right_line, edge_img, hough_roi_verts = self.detect_lane_hough(roi)

        # 하단 x 좌표를 차선 위치로 사용
        cx_left  = left_line[0]  if left_line  is not None else -1
        cx_right = right_line[0] if right_line is not None else -1

        if cx_left != -1 and cx_right != -1:
            new_width = cx_right - cx_left
            if new_width > 50:
                self.lane_width = new_width

        # ── 횡단보도 감지 ──
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        mask_black_raw = cv2.inRange(hsv, np.array([47, 0, 96]), np.array([180, 255, 132]))
        mask_black, removed_rows = self.remove_crosswalk(mask_black_raw)
        self.crosswalk_detected = (removed_rows > roi_h * 0.3)

        # ── 장애물 감지 ──
        mask_gray = cv2.inRange(hsv, np.array([0, 0, 178]), np.array([180, 20, 255]))
        contours, _ = cv2.findContours(mask_gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        valid_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 1000]
        obstacle_detected = len(valid_contours) > 0
        obstacle_in_front = False
        largest_cnt = None

        black_left_val  = cv2.countNonZero(mask_black[:, :roi_w // 2])
        black_right_val = cv2.countNonZero(mask_black[:, roi_w // 2:])
        avoid_direction = 1 if black_left_val > black_right_val else -1

        if obstacle_detected:
            largest_cnt = max(valid_contours, key=cv2.contourArea)
            M = cv2.moments(largest_cnt)
            if M['m00'] > 0:
                obj_cx = int(M['m10'] / M['m00'])
                if int(roi_w * 0.3) <= obj_cx <= int(roi_w * 0.7):
                    obstacle_in_front = True

        # ── 적색선 / 황색선 감지 ──
        mask_red = cv2.bitwise_or(
            cv2.inRange(hsv, np.array([0,   30,  49]), np.array([12,  255, 255])),
            cv2.inRange(hsv, np.array([170, 120, 70]), np.array([180, 255, 255]))
        )
        mask_yellow = cv2.inRange(hsv, np.array([20, 65, 120]), np.array([41, 255, 255]))
        red_line_detected    = cv2.countNonZero(mask_red)    > 5000
        yellow_line_detected = cv2.countNonZero(mask_yellow) > 5000

        # ── 조향 목표 계산 ──
        if self.crosswalk_detected:
            target_x = self.last_valid_target_x
        else:
            if cx_left != -1 and cx_right != -1:
                target_x = (cx_left + cx_right) // 2
            elif cx_left != -1:
                target_x = cx_left + (self.lane_width // 2)
            elif cx_right != -1:
                target_x = cx_right - (self.lane_width // 2)
            else:
                target_x = roi_w // 2
            target_x = self.smooth_value(self.target_x_history, target_x)
            self.last_valid_target_x = target_x

        error = (roi_w / 2) - target_x

        # ── 제어 노드 전송 ──
        status_msg = String()
        status_msg.data = (
            f"{error}|"
            f"{1 if red_line_detected    else 0}|"
            f"{1 if obstacle_in_front    else 0}|"
            f"{1 if self.crosswalk_detected else 0}|"
            f"{avoid_direction}|"
            f"{1 if obstacle_detected    else 0}|"
            f"{1 if yellow_line_detected else 0}"
        )
        self.vision_pub.publish(status_msg)

        # ── 디버그 시각화 ──
        overlay = roi.copy()
        overlay = draw_lane_lines(overlay, left_line, right_line)
        cv2.polylines(overlay, [hough_roi_verts], isClosed=True, color=(255, 0, 0), thickness=2)

        if largest_cnt is not None:
            x, y, w, h = cv2.boundingRect(largest_cnt)
            color = (0, 0, 255) if obstacle_in_front else (0, 200, 255)
            cv2.rectangle(overlay, (x, y), (x + w, y + h), color, 2)
            cv2.putText(overlay, "OBS" + (" FRONT" if obstacle_in_front else ""),
                        (x, max(y - 5, 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1)

        draw_y = int(roi_h * 0.9)
        if cx_left  != -1: cv2.circle(overlay, (cx_left,  draw_y), 8,  (255, 0, 255), -1)
        if cx_right != -1: cv2.circle(overlay, (cx_right, draw_y), 8,  (255, 0, 255), -1)
        cv2.circle(overlay, (target_x, draw_y), 12, (0, 0, 255), -1)
        cv2.line(overlay, (roi_w // 2, 0), (roi_w // 2, roi_h), (180, 180, 180), 1)

        state_color = {"CRUISE": (255,255,255), "AVOID": (0,165,255), "STOP_TIMER": (0,0,255)}
        status_text = f"State:{self.current_control_state}"
        if self.crosswalk_detected:
            status_text += " [CROSSWALK]"
        cv2.putText(overlay, status_text, (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
                    state_color.get(self.current_control_state, (255,255,255)), 2)
        cv2.putText(overlay, f"Cmd:{self.last_sent_cmd}",             (10, 44), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,200), 1)
        cv2.putText(overlay, f"RED:{'ON' if red_line_detected else 'off'}", (10, 64),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255) if red_line_detected else (100,100,100), 1)
        cv2.putText(overlay, f"err:{error:.1f}", (10, 84), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,0), 1)

        # 하단 디버그 마스크
        def make_mask_vis(mask, color, label):
            vis = np.zeros((mask.shape[0], mask.shape[1], 3), dtype=np.uint8)
            vis[mask > 0] = color
            cv2.putText(vis, label, (5, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
            return vis

        edge_vis = cv2.cvtColor(edge_img, cv2.COLOR_GRAY2BGR)
        cv2.putText(edge_vis, "EDGE", (5, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

        cell_w = roi_w // 4
        cell_h = int(roi_h * 0.4)
        m_e = cv2.resize(edge_vis,                                             (cell_w, cell_h))
        m_b = cv2.resize(make_mask_vis(mask_black, (0,255,0),   "BLACK"),     (cell_w, cell_h))
        m_o = cv2.resize(make_mask_vis(mask_gray,  (255,200,0), "OBS"),       (cell_w, cell_h))
        m_r = cv2.resize(make_mask_vis(mask_red,   (0,0,255),   "RED"),       (roi_w - cell_w * 3, cell_h))

        mask_row    = cv2.resize(np.hstack([m_e, m_b, m_o, m_r]), (roi_w, cell_h))
        debug_final = np.vstack([overlay, mask_row])

        compressed_msg = CompressedImage()
        compressed_msg.header.stamp    = self.get_clock().now().to_msg()
        compressed_msg.header.frame_id = "camera_frame"
        compressed_msg.format          = "jpeg"
        compressed_msg.data            = cv2.imencode('.jpg', debug_final)[1].tobytes()
        self.image_pub.publish(compressed_msg)


def main(args=None):
    rclpy.init(args=args)
    node = VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
